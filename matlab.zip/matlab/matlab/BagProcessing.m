%bag = rosbag('2023-02-17-15-45-27.bag');
bag= rosbag('marker1e2_ciclo1.bag');
%tf_bagInfo = rosbag('info','tf_bag.bag')


%Sincronization of the bag files


tf_bsel=select(bag,'Topic','/tf');
tf_msgStructs = readMessages(tf_bsel,'DataFormat','struct');

gazebo_bsel=select(bag,'Topic','/gazebo/model_states');
gazebo_msgStructs = readMessages(gazebo_bsel,'DataFormat','struct');

pose_bsel=select(bag,'Topic','/base_pose');
pose_msgStructs = readMessages(pose_bsel,'DataFormat','struct');


%Extract real base_footprint position
base_pose=timeseries;
for i=1:height(gazebo_bsel.MessageList)
    base_pose=addsample(base_pose,'Data',[ gazebo_msgStructs{i,1}.Pose(32).Position.X ...
                          gazebo_msgStructs{i,1}.Pose(32).Position.Y ...
                          gazebo_msgStructs{i,1}.Pose(32).Position.Z ],...
                  'Time',gazebo_bsel.MessageList{i,'Time'});
end

base_pose.TimeInfo.Units = 'seconds';
base_pose.Time = base_pose.Time - bag.StartTime;
%plot(base_pose)



%Extract estimated base_footprint position
est_pose=timeseries;
for i=1:height(pose_bsel.MessageList)
    est_pose=addsample(est_pose,'Data',[ pose_msgStructs{i,1}.Point.X ...
                          pose_msgStructs{i,1}.Point.Y ...
                          pose_msgStructs{i,1}.Point.Z ],...
                  'Time',pose_bsel.MessageList{i,'Time'});
end

est_pose.TimeInfo.Units = 'seconds';
est_pose.Time = est_pose.Time - bag.StartTime;

[ts1 ts2] = synchronize(base_pose,est_pose,'Uniform','Interval',0.1);

%Compute SLAM error: component-wise or norm?
base_error=ts1;
base_error.Data=abs(ts1.Data-ts2.Data);

norm_base_error=ts1;
norm_base_error.Data=vecnorm(base_error.Data,2,2);


%Exact position of the markers

marker_1=  [gazebo_msgStructs{1,1}.Pose(17).Position.X ...
                   gazebo_msgStructs{1,1}.Pose(17).Position.Y ...
                   gazebo_msgStructs{1,1}.Pose(17).Position.Z];



marker_2=  [gazebo_msgStructs{1,1}.Pose(16).Position.X ...
                   gazebo_msgStructs{1,1}.Pose(16).Position.Y ...
                   gazebo_msgStructs{1,1}.Pose(16).Position.Z];  


marker_3=  [gazebo_msgStructs{1,1}.Pose(13).Position.X ...
                   gazebo_msgStructs{1,1}.Pose(13).Position.Y ...
                   gazebo_msgStructs{1,1}.Pose(13).Position.Z];


marker_4=  [gazebo_msgStructs{1,1}.Pose(12).Position.X ...
                   gazebo_msgStructs{1,1}.Pose(12).Position.Y ...
                   gazebo_msgStructs{1,1}.Pose(12).Position.Z];      

%Extract estimated position of markers wrt map
est_m1=timeseries;
est_m2=timeseries;
est_m3=timeseries;
est_m4=timeseries;

est_m1.TimeInfo.Units = 'seconds';
est_m2.TimeInfo.Units = 'seconds';
est_m3.TimeInfo.Units = 'seconds';
est_m4.TimeInfo.Units = 'seconds';


for i=1:length(tf_msgStructs)
    if string(tf_msgStructs{i,1}.Transforms.Header.FrameId) == "/map"
        if string(tf_msgStructs{i,1}.Transforms.ChildFrameId) == "/marker_1"
            est_m1=addsample(est_m1,'Data',[tf_msgStructs{i,1}.Transforms.Transform.Translation.X ...
                                            tf_msgStructs{i,1}.Transforms.Transform.Translation.Y ...
                                            tf_msgStructs{i,1}.Transforms.Transform.Translation.Z ],...
                                            'Time',tf_bsel.MessageList{i,'Time'});
           
        elseif string(tf_msgStructs{i,1}.Transforms.ChildFrameId) == "/marker_2"
            est_m2=addsample(est_m2,'Data',[tf_msgStructs{i,1}.Transforms.Transform.Translation.X ...
                                            tf_msgStructs{i,1}.Transforms.Transform.Translation.Y ...
                                            tf_msgStructs{i,1}.Transforms.Transform.Translation.Z ],...
                                            'Time',tf_bsel.MessageList{i,'Time'});
        elseif string(tf_msgStructs{i,1}.Transforms.ChildFrameId) == "/marker_3"
            est_m3=addsample(est_m3,'Data',[tf_msgStructs{i,1}.Transforms.Transform.Translation.X ...
                                            tf_msgStructs{i,1}.Transforms.Transform.Translation.Y ...
                                            tf_msgStructs{i,1}.Transforms.Transform.Translation.Z ],...
                                            'Time',tf_bsel.MessageList{i,'Time'});
        elseif string(tf_msgStructs{i,1}.Transforms.ChildFrameId) == "/marker_4"
            est_m4=addsample(est_m4,'Data',[tf_msgStructs{i,1}.Transforms.Transform.Translation.X ...
                                            tf_msgStructs{i,1}.Transforms.Transform.Translation.Y ...
                                            tf_msgStructs{i,1}.Transforms.Transform.Translation.Z ],...
                                            'Time',tf_bsel.MessageList{i,'Time'});
        end

    end


end

est_m1.Time = est_m1.Time - bag.StartTime;
est_m2.Time = est_m2.Time - bag.StartTime;
est_m3.Time = est_m3.Time - bag.StartTime;
est_m4.Time = est_m4.Time - bag.StartTime;

%PLOT


error_m1=est_m1;
error_m1.Data = vecnorm(abs(error_m1.Data - marker_1),2,2);
[error_m1_plot norm_error_plot]=synchronize(error_m1, norm_base_error, 'Uniform','Interval',0.1);
error_m1_plot.Name='Norma errore marker 1 sulle tre componenti';

error_plot.Name='Errore di localizzazione';
figure()
subplot(2,1,1)
plot(error_m1_plot,'LineWidth',2),grid minor;
ylabel('errore marker');
xlabel('tempo [s]');

subplot(2,1,2);
plot(norm_error_plot,'LineWidth',2),grid minor;
ylabel('errore posizione')
xlabel('tempo [s]');


error_m2=est_m2;
error_m2.Data = vecnorm(abs(error_m2.Data - marker_2),2,2);
[error_m2_plot norm_error_plot]=synchronize(error_m2, norm_base_error, 'Uniform','Interval',0.1);
error_m2_plot.Name='Norma errore marker 2 sulle tre componenti';
norm_error_plot.Name='Errore di localizzazione';
figure()
subplot(2,1,1)
plot(error_m2_plot,'LineWidth',2),grid minor;
ylabel('errore marker');
xlabel('tempo [s]');

subplot(2,1,2);
plot(norm_error_plot,'LineWidth',2),grid minor;
ylabel('errore posizione')
xlabel('tempo [s]');
%PLOT: POSIZIONE RELATIVA DEL MARKER 1 RISPETTO AL ROBOT

m1_base_est=timeseries;
[t1 t2]=synchronize(est_m1,est_pose,'Uniform','Interval',0.1);
m1_base_est.Time=t1.Time;
m1_base_est.Data=vecnorm(abs(t1.Data - t2.Data),2,2);
[t1 t2]=synchronize(est_m1,base_pose,'Uniform','Interval',0.1);
m1_base=t2;
m1_base.Data=vecnorm(abs(t2.Data-marker_1),2,2);

%[m1_base_est_plot m1_base_plot]=synchronize(m1_base_est,m1_base,'Uniform','Interval',0.1);
figure()
plot(m1_base_est,'LineWidth',2);
hold on
plot(m1_base,'LineWidth',2),grid minor;
legend('Stimata','Reale');
ylabel('distanza')
title('Distanza del robot dal marker 1');

%PLOT: POSIZIONE RELATIVA DEL MARKER 2 RISPETTO AL ROBOT

m2_base_est=timeseries;
[t1 t2]=synchronize(est_m2,est_pose,'Uniform','Interval',0.1);
m2_base_est.Time=t1.Time;
m2_base_est.Data=vecnorm(abs(t1.Data - t2.Data),2,2);
[t1 t2]=synchronize(est_m2,base_pose,'Uniform','Interval',0.1);
m2_base=t2;
m2_base.Data=vecnorm(abs(t2.Data-marker_2),2,2);

%[m1_base_est_plot m1_base_plot]=synchronize(m1_base_est,m1_base,'Uniform','Interval',0.1);
figure()
plot(m2_base_est,'LineWidth',2);
hold on
plot(m2_base,'LineWidth',2),grid minor;
legend('Stimata','Reale');
ylabel('distanza')
title('Distanza del robot dal marker 2');


% error_m3=est_m3;
% error_m3.Data = vecnorm(abs(error_m3.Data - marker_3),2,2);
% [error_m3_plot norm_error_plot]=synchronize(error_m3, norm_base_error, 'Uniform','Interval',0.1);
% error_m3_plot.Name='Norma errore marker 3 sulle tre componenti';
% norm_error_plot.Name='Errore di localizzazione';
% figure()
% subplot(2,1,1)
% plot(error_m3_plot);
% ylabel('errore marker');
% 
% subplot(2,1,2);
% plot(norm_error_plot);
% ylabel('errore posizione');
% 
% %PLOT: POSIZIONE RELATIVA DEL MARKER 3 RISPETTO AL ROBOT
% 
% m3_base_est=timeseries;
% [t1 t2]=synchronize(est_m3,est_pose,'Uniform','Interval',0.1);
% m3_base_est.Time=t1.Time;
% m3_base_est.Data=vecnorm(abs(t1.Data - t2.Data),2,2);
% [t1 t2]=synchronize(est_m3,base_pose,'Uniform','Interval',0.1);
% m3_base=t2;
% m3_base.Data=vecnorm(abs(t2.Data-marker_3),2,2);
% 
% %[m1_base_est_plot m1_base_plot]=synchronize(m1_base_est,m1_base,'Uniform','Interval',0.1);
% figure()
% plot(m3_base_est);
% hold on
% plot(m3_base);
% legend('Stimata','Reale');
% ylabel('distanza')
% title('Distanza del robot dal marker 3');


% error_m4=est_m4;
% error_m4.Data = vecnorm(abs(error_m4.Data - marker_4),2,2);
% [error_m4_plot norm_error_plot]=synchronize(error_m4, norm_base_error, 'Uniform','Interval',0.1);
% error_m4_plot.Name='Errore marker 4 sulle tre componenti';
% norm_error_plot.Name='Errore di localizzazione';
% figure()
% subplot(2,1,1)
% plot(error_m4_plot);
% ylabel('errore marker');
% xlabel('tempo (s)');
% 
% subplot(2,1,2);
% plot(norm_error_plot);
% ylabel('errore posizione');
% xlabel('tempo (s)');
% 
% 
% 
% PLOT: POSIZIONE RELATIVA DEL MARKER 4 RISPETTO AL ROBOT
% 
% m4_base_est=timeseries;
% [t1 t2]=synchronize(est_m4,est_pose,'Uniform','Interval',0.1);
% m4_base_est.Time=t1.Time;
% m4_base_est.Data=vecnorm(abs(t1.Data - t2.Data),2,2);
% [t1 t2]=synchronize(est_m4,base_pose,'Uniform','Interval',0.1);
% m4_base=t2;
% m4_base.Data=vecnorm(abs(t2.Data-marker_4),2,2);
% 
% [m1_base_est_plot m1_base_plot]=synchronize(m1_base_est,m1_base,'Uniform','Interval',0.1);
% figure()
% plot(m4_base_est);
% hold on
% plot(m4_base);
% legend('Stimata','Reale');
% ylabel('distanza')
% title('Distanza del robot dal marker 4');

