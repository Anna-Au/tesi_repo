%bag = rosbag('2023-02-17-15-45-27.bag');
bag= rosbag('ciclo2.bag');
%tf_bagInfo = rosbag('info','tf_bag.bag')


%Sincronization of the bag files


tf_bsel=select(bag,'Topic','/tf');
tf_msgStructs = readMessages(tf_bsel,'DataFormat','struct');

gazebo_bsel=select(bag,'Topic','/gazebo/model_states');
gazebo_msgStructs = readMessages(gazebo_bsel,'DataFormat','struct');

pose_bsel=select(bag,'Topic','/base_pose');
pose_msgStructs = readMessages(pose_bsel,'DataFormat','struct');


%Extract real base_footprint position
base_pose=timeseries;
for i=1:height(gazebo_bsel.MessageList)
    base_pose=addsample(base_pose,'Data',[ gazebo_msgStructs{i,1}.Pose(32).Position.X ...
                          gazebo_msgStructs{i,1}.Pose(32).Position.Y ...
                          gazebo_msgStructs{i,1}.Pose(32).Position.Z ],...
                  'Time',gazebo_bsel.MessageList{i,'Time'});
end

base_pose.TimeInfo.Units = 'seconds';
base_pose.Time = base_pose.Time - bag.StartTime;
%plot(base_pose)



%Extract estimated base_footprint position
est_pose=timeseries;
for i=1:height(pose_bsel.MessageList)
    est_pose=addsample(est_pose,'Data',[ pose_msgStructs{i,1}.Point.X ...
                          pose_msgStructs{i,1}.Point.Y ...
                          pose_msgStructs{i,1}.Point.Z ],...
                  'Time',pose_bsel.MessageList{i,'Time'});
end

est_pose.TimeInfo.Units = 'seconds';
est_pose.Time = est_pose.Time - bag.StartTime;

[ts1 ts2] = synchronize(base_pose,est_pose,'Uniform','Interval',0.1);

%Compute SLAM error: component-wise or norm?
base_error=ts1;
base_error.Data=abs(ts1.Data-ts2.Data);

norm_base_error=ts1;
norm_base_error.Data=vecnorm(base_error.Data,2,2);


%Exact position of the markers

marker_1=  [gazebo_msgStructs{1,1}.Pose(17).Position.X ...
                   gazebo_msgStructs{1,1}.Pose(17).Position.Y ...
                   gazebo_msgStructs{1,1}.Pose(17).Position.Z];



marker_2=  [gazebo_msgStructs{1,1}.Pose(16).Position.X ...
                   gazebo_msgStructs{1,1}.Pose(16).Position.Y ...
                   gazebo_msgStructs{1,1}.Pose(16).Position.Z];  


marker_3=  [gazebo_msgStructs{1,1}.Pose(13).Position.X ...
                   gazebo_msgStructs{1,1}.Pose(13).Position.Y ...
                   gazebo_msgStructs{1,1}.Pose(13).Position.Z];


marker_4=  [gazebo_msgStructs{1,1}.Pose(12).Position.X ...
                   gazebo_msgStructs{1,1}.Pose(12).Position.Y ...
                   gazebo_msgStructs{1,1}.Pose(12).Position.Z];      

%Extract estimated position of markers wrt map
est_m1=timeseries;
est_m2=timeseries;
est_m3=timeseries;
est_m4=timeseries;

est_m1.TimeInfo.Units = 'seconds';
est_m2.TimeInfo.Units = 'seconds';
est_m3.TimeInfo.Units = 'seconds';
est_m4.TimeInfo.Units = 'seconds';


for i=1:length(tf_msgStructs)
    if string(tf_msgStructs{i,1}.Transforms.Header.FrameId) == "/map"
        if string(tf_msgStructs{i,1}.Transforms.ChildFrameId) == "/marker_1"
            est_m1=addsample(est_m1,'Data',[tf_msgStructs{i,1}.Transforms.Transform.Translation.X ...
                                            tf_msgStructs{i,1}.Transforms.Transform.Translation.Y ...
                                            tf_msgStructs{i,1}.Transforms.Transform.Translation.Z ],...
                                            'Time',tf_bsel.MessageList{i,'Time'});
           
        elseif string(tf_msgStructs{i,1}.Transforms.ChildFrameId) == "/marker_2"
            est_m2=addsample(est_m2,'Data',[tf_msgStructs{i,1}.Transforms.Transform.Translation.X ...
                                            tf_msgStructs{i,1}.Transforms.Transform.Translation.Y ...
                                            tf_msgStructs{i,1}.Transforms.Transform.Translation.Z ],...
                                            'Time',tf_bsel.MessageList{i,'Time'});
        elseif string(tf_msgStructs{i,1}.Transforms.ChildFrameId) == "/marker_3"
            est_m3=addsample(est_m3,'Data',[tf_msgStructs{i,1}.Transforms.Transform.Translation.X ...
                                            tf_msgStructs{i,1}.Transforms.Transform.Translation.Y ...
                                            tf_msgStructs{i,1}.Transforms.Transform.Translation.Z ],...
                                            'Time',tf_bsel.MessageList{i,'Time'});
        elseif string(tf_msgStructs{i,1}.Transforms.ChildFrameId) == "/marker_4"
            est_m4=addsample(est_m4,'Data',[tf_msgStructs{i,1}.Transforms.Transform.Translation.X ...
                                            tf_msgStructs{i,1}.Transforms.Transform.Translation.Y ...
                                            tf_msgStructs{i,1}.Transforms.Transform.Translation.Z ],...
                                            'Time',tf_bsel.MessageList{i,'Time'});
        end

    end


end

est_m1.Time = est_m1.Time - bag.StartTime;
est_m2.Time = est_m2.Time - bag.StartTime;
est_m3.Time = est_m3.Time - bag.StartTime;
est_m4.Time = est_m4.Time - bag.StartTime;

%costruzione percorso
%stimato
xy_est=sqrt(ts2.Data(:,1).^2+ts2.Data(:,2).^2);
%reale
xy=sqrt(ts1.Data(:,1).^2+ts1.Data(:,2).^2);
%marker
m=sqrt(est_m4.Data(:,1).^2+est_m4.Data(:,2).^2);

%%visualizzazione percorso e marker

% figure()
% xlabel('[m]');
% ylabel('[m]');
% 
% 
% scatter(ts1.Data(:,1),ts1.Data(:,2),20,'filled')
% hold on
% scatter(ts2.Data(:,1),ts2.Data(:,2),20,'filled')
% hold on
% scatter(marker_1(1),marker_1(2),'filled')
% hold on
% scatter(marker_2(1),marker_2(2),'filled')
% hold on
% scatter(marker_3(1),marker_3(2),'filled')
% hold on
% scatter(marker_4(1),marker_4(2),'filled')
% hold on
% 
% scatter(est_m1.Data(:,1),est_m1.Data(:,2),15,'Marker','*')
% hold on
% scatter(est_m2.Data(:,1),est_m2.Data(:,2),15,'Marker','*')
% hold on
% scatter(est_m3.Data(:,1),est_m3.Data(:,2),15,'Marker','*')
% hold on
% scatter(est_m4.Data(:,1),est_m4.Data(:,2),15,'Marker','*')
% 
% legend('posizione robot','posizione stimata','marker 1','marker 2','marker 3','marker 4',....
%     'stima marker 1','stima marker 2','stima marker 3','stima marker 4')

